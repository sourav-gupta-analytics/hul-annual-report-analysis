# HUL Financial Performance Intelligence

Editable three-page Power BI project (PBIP/PBIR with TMSL model). Independent portfolio analysis of HUL standalone continuing operations, FY25 restated versus FY26. All amounts are INR crore.

Open the PBIP using Power BI Desktop; refresh the embedded data. See START_HERE.txt and validation-expected.json. The source tables are copied from the previously prepared project kit. The model has one Year dimension, two fact tables and a disconnected profit bridge. No external credentials or paths.

## Key insights
- Turnover grew from 58,965 to 61,315 crore; EBITDA grew more slowly, from 14,144 to 14,464 crore.
- EBITDA margin decreased from approximately 23.70% to 23.34%.
- Continuing PAT increased from 10,653 to 11,020 crore. The 367 crore increase is reconciled by EBIT +256, other income -231, exceptional credit -258 and tax expense reduction +600.
- Home Care is the largest segment; Beauty & Wellbeing has the highest FY26 turnover growth among the five categories.

## Source and limitations
[HUL Integrated Annual Report FY26](https://www.hul.co.in/files/annual-report-2025-26-single-page.pdf), printed page 90, as documented in supplied CSVs. FY25 is restated for comparable continuing operations. Only two comparable periods; no forecast, causal claims or production deployment. Historical CSV is reference only. Source file is preserved; new editable report was generated with AI assistance. Desktop validation and final PBIX publication are pending.

## Refined edition
Version 1 opened in Power BI Desktop; screenshots showed working FY26 filtering and the expected growth/margin, segment movement and PAT bridge. Version 2 preserves the tested semantic model and source data, expands the scorecards and revises visual formatting. The revised layout requires Desktop verification before publication.
